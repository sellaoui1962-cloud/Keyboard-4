package com.kimikb.keyboard

class Palette(
    val bg: Int,        // keyboard background
    val key: Int,       // normal key
    val keyAlt: Int,    // special key (shift, 123, ...)
    val shadow: Int,    // key shadow
    val text: Int,      // key text
    val special: Int,   // accent text / highlights
    val enterBg: Int,   // enter key + active shift
    val enterText: Int,
    val hint: Int,      // small corner hints
    val isLight: Boolean
)

object Themes {
    const val COUNT = 4
    val names = arrayOf("فاتح", "داكن", "AMOLED", "محيط")

    private val all = arrayOf(
        // 0: light
        Palette(0xFFE9ECF1.toInt(), 0xFFFFFFFF.toInt(), 0xFFCDD3DC.toInt(), 0xFFB3BAC6.toInt(),
            0xFF1F2328.toInt(), 0xFF00796B.toInt(), 0xFF00897B.toInt(), 0xFFFFFFFF.toInt(),
            0xFF8A919B.toInt(), true),
        // 1: dark
        Palette(0xFF131314.toInt(), 0xFF2E2F31.toInt(), 0xFF3C4043.toInt(), 0xFF0B0B0C.toInt(),
            0xFFE8EAED.toInt(), 0xFF4DD0E1.toInt(), 0xFF4DD0E1.toInt(), 0xFF00363D.toInt(),
            0xFF7C8187.toInt(), false),
        // 2: AMOLED
        Palette(0xFF000000.toInt(), 0xFF161617.toInt(), 0xFF232324.toInt(), 0xFF0A0A0A.toInt(),
            0xFFFFFFFF.toInt(), 0xFF4DD0E1.toInt(), 0xFF4DD0E1.toInt(), 0xFF00363D.toInt(),
            0xFF6E7378.toInt(), false),
        // 3: ocean
        Palette(0xFF0D1B2A.toInt(), 0xFF1B2B40.toInt(), 0xFF27405C.toInt(), 0xFF08111C.toInt(),
            0xFFE0ECF8.toInt(), 0xFF7FD1FF.toInt(), 0xFF2E86DE.toInt(), 0xFFFFFFFF.toInt(),
            0xFF6F89A6.toInt(), false)
    )

    fun get(i: Int): Palette = all[i.coerceIn(0, COUNT - 1)]
}
