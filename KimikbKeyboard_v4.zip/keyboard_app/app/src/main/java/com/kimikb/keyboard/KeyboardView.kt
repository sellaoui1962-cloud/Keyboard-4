package com.kimikb.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import kotlin.math.abs

class KeySpec(val label: String, val token: String, val w: Float = 1f, val hint: String = "")

class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(t: String)        // commit a character / string
        fun onSpecial(token: String) // @DEL @SHIFT @ENTER @SEND @SPACE @LANG @NUM @ABC @EMOJI @SYM @SET
    }

    var listener: Listener? = null
    var rows: List<List<KeySpec>> = emptyList()
        set(v) { field = v; requestLayout(); invalidate() }

    // theme: 0 light, 1 dark, 2 amoled, 3 ocean
    var theme = 1
    private var pal: Palette = Themes.get(1)

    private val d = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private class Ptr(val row: Int, val col: Int, val downX: Float, val key: KeySpec?) {
        var swiped = false
        var consumed = false
        var lp: Runnable? = null
    }
    private val ptrs = HashMap<Int, Ptr>()
    private val longPressHandler = Handler(Looper.getMainLooper())

    private fun isDown(r: Int, c: Int): Boolean {
        for (p in ptrs.values) if (p.row == r && p.col == c) return true
        return false
    }

    private fun cancelLp(p: Ptr) {
        p.lp?.let { longPressHandler.removeCallbacks(it) }
        p.lp = null
    }

    override fun onDetachedFromWindow() {
        longPressHandler.removeCallbacksAndMessages(null)
        ptrs.clear()
        popup?.dismiss()
        super.onDetachedFromWindow()
    }
    private var popup: PopupWindow? = null

    val alternates = mapOf(
        'ا' to "أ إ آ", 'و' to "ؤ", 'ي' to "ئ", 'ة' to "ه", 'ل' to "لا",
        'e' to "é è ê ë", 'a' to "à â ä", 'i' to "î ï", 'o' to "ô ö",
        'u' to "ù û ü", 'c' to "ç", 'n' to "ñ",
        '.' to "…", '?' to "¿", '!' to "¡", '٪' to "؟ ! …", '@' to "# _ / :"
    )

    fun applyTheme(t: Int) {
        theme = t
        pal = Themes.get(t)
        invalidate()
    }

    // service tells view when shift is active so FR letters render uppercase
    var shiftActive = false
    var capsActive = false
    var showHints = true
    private fun shiftUpper() = shiftActive || capsActive

    private fun rowHeight(): Int = (54f * d).toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY)
            MeasureSpec.getSize(widthMeasureSpec) else (d * 360).toInt()
        val h = rowHeight() * rows.size.coerceAtLeast(1)
        setMeasuredDimension(w, h)
    }

    private fun shade(c: Int, f: Float): Int {
        val r = (((c shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((c shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((c and 0xFF) * f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    override fun onDraw(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.color = pal.bg
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        if (rows.isEmpty()) return
        val rh = height.toFloat() / rows.size
        val pad = 3f * d
        val sh = 1.6f * d
        val radius = 10f * d
        var pressedLabel: String? = null
        var pressedBox: RectF? = null
        var y = 0f
        for ((ri, row) in rows.withIndex()) {
            var x = 0f
            val total = row.sumOf { it.w.toDouble() }.toFloat()
            for ((ci, key) in row.withIndex()) {
                val kw = width * key.w / total
                val isPressed = isDown(ri, ci)
                val special = key.token.startsWith("@")
                val isEnter = key.token == "@SEND"
                val shiftOn = key.token == "@SHIFT" && (shiftActive || capsActive)
                val hot = isEnter || shiftOn
                val base = when {
                    hot -> pal.enterBg
                    special -> pal.keyAlt
                    else -> pal.key
                }
                val fill = if (isPressed) shade(base, if (pal.isLight) 0.86f else 1.35f) else base
                val left = x + pad
                val top = y + pad
                val right = x + kw - pad
                val bottom = y + rh - pad - sh

                paint.style = Paint.Style.FILL
                if (key.token == "@SHIFT" || key.token == "@DEL") {
                    // round keys
                    val rc = minOf(kw, rh) / 2f - pad
                    val cx = (left + right) / 2f
                    val cy = (top + bottom) / 2f
                    paint.color = pal.shadow
                    canvas.drawCircle(cx, cy + sh, rc, paint)
                    paint.color = fill
                    canvas.drawCircle(cx, cy, rc, paint)
                } else {
                    rect.set(left, top + sh, right, bottom + sh)
                    paint.color = pal.shadow
                    canvas.drawRoundRect(rect, radius, radius, paint)
                    rect.set(left, top, right, bottom)
                    paint.color = fill
                    canvas.drawRoundRect(rect, radius, radius, paint)
                }

                var label = key.label
                if (key.token == "@SHIFT" && capsActive) label = "⇪"
                if (shiftUpper() && !special) label = label.uppercase()
                paint.textAlign = Paint.Align.CENTER
                paint.color = when {
                    hot -> pal.enterText
                    special -> pal.special
                    else -> pal.text
                }
                paint.textSize = (rh * 0.34f).coerceAtMost(kw * 0.42f)
                val maxW = kw - pad * 4f
                while (paint.measureText(label) > maxW && paint.textSize > 9f * d) {
                    paint.textSize = paint.textSize - 1f
                }
                val yText = (top + bottom) / 2f - (paint.descent() + paint.ascent()) / 2f
                canvas.drawText(label, (left + right) / 2f, yText, paint)

                // small corner hint (numbers / alternate letters)
                if (showHints && key.hint.isNotEmpty() && !special) {
                    paint.textSize = (rh * 0.17f).coerceAtMost(kw * 0.22f)
                    paint.color = pal.hint
                    paint.textAlign = Paint.Align.RIGHT
                    canvas.drawText(key.hint, right - 3f * d, top + 3f * d - paint.ascent(), paint)
                    paint.textAlign = Paint.Align.CENTER
                }

                if (isPressed && !special) {
                    pressedBox = RectF(left, top, right, bottom)
                    pressedLabel = label
                }
                x += kw
            }
            y += rh
        }

        // key preview bubble above the pressed letter
        val pb = pressedBox
        val pl = pressedLabel
        if (pb != null && pl != null) {
            val bw = pb.width() * 1.4f
            val bh = rh * 1.1f
            val bcx = pb.centerX().coerceIn(bw / 2f, width - bw / 2f)
            val btop = (pb.top - bh - 2f * d).coerceAtLeast(0f)
            rect.set(bcx - bw / 2f, btop, bcx + bw / 2f, btop + bh)
            paint.style = Paint.Style.FILL
            paint.color = shade(pal.key, if (pal.isLight) 0.97f else 1.5f)
            canvas.drawRoundRect(rect, radius * 1.3f, radius * 1.3f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f * d
            paint.color = pal.special
            canvas.drawRoundRect(rect, radius * 1.3f, radius * 1.3f, paint)
            paint.style = Paint.Style.FILL
            paint.color = pal.text
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = bh * 0.5f
            canvas.drawText(pl, rect.centerX(),
                rect.centerY() - (paint.descent() + paint.ascent()) / 2f, paint)
        }
    }

    private fun keyAt(x: Float, y: Float): Pair<Int, Int> {
        if (rows.isEmpty()) return -1 to -1
        val rh = height.toFloat() / rows.size
        val ri = (y / rh).toInt().coerceIn(0, rows.size - 1)
        val row = rows[ri]
        val total = row.sumOf { it.w.toDouble() }.toFloat()
        var acc = 0f
        for ((ci, key) in row.withIndex()) {
            val kw = width * key.w / total
            if (x < acc + kw) return ri to ci
            acc += kw
        }
        return ri to row.lastIndex
    }

    private fun fireKey(k: KeySpec) {
        if (k.token.startsWith("@")) {
            listener?.onSpecial(k.token)
        } else {
            var out = k.label
            if (shiftUpper()) out = out.uppercase()
            listener?.onText(out)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = event.actionIndex
                val id = event.getPointerId(idx)
                val x = event.getX(idx)
                val y = event.getY(idx)
                val (r, c) = keyAt(x, y)
                val key = rows.getOrNull(r)?.getOrNull(c)
                val ptr = Ptr(r, c, x, key)
                ptrs[id] = ptr
                if (key != null) {
                    val run = Runnable { onLongPress(ptr, key) }
                    ptr.lp = run
                    longPressHandler.postDelayed(run, 420)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                // swipe left on backspace = delete whole word
                for (i in 0 until event.pointerCount) {
                    val ptr = ptrs[event.getPointerId(i)] ?: continue
                    if (ptr.key?.token == "@DEL" && !ptr.swiped && abs(event.getX(i) - ptr.downX) > 110) {
                        ptr.swiped = true
                        cancelLp(ptr)
                        listener?.onSpecial("@DEL_WORD")
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = event.getPointerId(event.actionIndex)
                val ptr = ptrs.remove(id)
                if (ptr != null) {
                    cancelLp(ptr)
                    val k = ptr.key
                    if (k != null && !ptr.consumed && !ptr.swiped) fireKey(k)
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                for (p in ptrs.values) cancelLp(p)
                ptrs.clear()
                invalidate()
            }
        }
        return true
    }

    private fun chipView(text: String, sp: Float, onClick: () -> Unit): TextView =
        TextView(context).apply {
            this.text = text
            textSize = sp
            gravity = Gravity.CENTER
            setTextColor(pal.text)
            background = GradientDrawable().apply {
                setColor(pal.key)
                cornerRadius = 10f * d
            }
            val p = (14f * d).toInt()
            setPadding(p, p / 2, p, p / 2)
            setOnClickListener { onClick() }
        }

    private fun addChip(row: LinearLayout, tv: TextView) {
        val m = (3f * d).toInt()
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(m, m, m, m)
        row.addView(tv, lp)
    }

    private fun showRowPopup(row: LinearLayout) {
        val pd = (6f * d).toInt()
        row.setPadding(pd, pd, pd, pd)
        row.background = GradientDrawable().apply {
            setColor(pal.bg)
            cornerRadius = 14f * d
            setStroke((1f * d).toInt().coerceAtLeast(1), pal.keyAlt)
        }
        popup?.dismiss()
        val anchor: View = this
        val pw = PopupWindow(row, ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(0))
        pw.isOutsideTouchable = true
        pw.elevation = 10f * d
        pw.showAtLocation(anchor, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
            0, anchor.height + (4f * d).toInt())
        popup = pw
    }

    private fun onLongPress(ptr: Ptr, key: KeySpec) {
        ptr.lp = null
        when (key.token) {
            "@DEL" -> { ptr.consumed = true; showDeletePopup(); return }
            "@SET" -> { ptr.consumed = true; listener?.onSpecial("@SET_LONG"); return }
            "@NUM" -> { ptr.consumed = true; listener?.onSpecial("@NUMPAD"); return }
        }
        val alts = alternates[key.label.firstOrNull()] ?: return
        ptr.consumed = true
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        alts.split(" ").filter { it.isNotEmpty() }.forEach { ch ->
            addChip(row, chipView(ch, 22f) {
                listener?.onText(ch)
                popup?.dismiss()
            })
        }
        showRowPopup(row)
    }

    private fun showDeletePopup() {
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("⌫ حرف|@DEL", "✕ كلمة|@DEL_WORD", "🗑 الكل|@DEL_ALL").forEach { item ->
            val sep = item.indexOf('|')
            val txt = item.substring(0, sep)
            val tok = item.substring(sep + 1)
            addChip(row, chipView(txt, 15f) {
                listener?.onSpecial(tok)
                popup?.dismiss()
            })
        }
        showRowPopup(row)
    }
}
