package com.kimikb.keyboard

import android.content.SharedPreferences

/** Shared shortcut storage used by the keyboard and the settings screen. */
object Shortcuts {

    private val defaults = listOf(
        "سلام=السلام عليكم ورحمة الله وبركاته",
        "وعليكم=وعليكم السلام ورحمة الله وبركاته",
        "مع السلامة=مع السلامة، إلى اللقاء 👋",
        "شكرا=شكراً جزيلاً 🌹",
        "عافاك=بارك الله فيك 🙏",
        "ان شاء الله=إن شاء الله 🤲",
        "صباح الخير=صباح الخير 🌅",
        "مساء الخير=مساء الخير 🌙",
        "بريدي=example@gmail.com",
        "tel=0612345678",
        "adr=المغرب"
    )

    /** First run: put the default shortcuts in place (only when nothing was ever saved). */
    fun ensureDefaults(prefs: SharedPreferences) {
        if (!prefs.contains("shortcuts")) {
            prefs.edit().putStringSet("shortcuts", defaults.toSet()).apply()
        }
    }

    /** trigger -> expansion */
    fun load(prefs: SharedPreferences): Map<String, String> {
        ensureDefaults(prefs)
        val raw = prefs.getStringSet("shortcuts", emptySet()) ?: emptySet()
        val out = HashMap<String, String>()
        for (item in raw) {
            val i = item.indexOf('=')
            if (i <= 0) continue
            out[item.substring(0, i)] = item.substring(i + 1)
        }
        return out
    }
}
