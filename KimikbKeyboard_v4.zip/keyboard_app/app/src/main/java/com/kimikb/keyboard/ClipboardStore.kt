package com.kimikb.keyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClipItem(val text: String, val pinned: Boolean, val time: Long)

/** Local clipboard history (stored only on the device). Newest first. */
class ClipboardStore(context: Context) {

    private val prefs = context.getSharedPreferences("kb_clips", Context.MODE_PRIVATE)
    private val maxUnpinned = 40

    fun load(): MutableList<ClipItem> {
        val out = mutableListOf<ClipItem>()
        try {
            val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(ClipItem(o.getString("t"), o.optBoolean("p", false), o.optLong("ts", 0L)))
            }
        } catch (e: Exception) {
            // corrupted data -> start fresh
        }
        return out
    }

    private fun save(items: List<ClipItem>) {
        val arr = JSONArray()
        for (item in items) {
            arr.put(JSONObject().put("t", item.text).put("p", item.pinned).put("ts", item.time))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    fun add(text: String) {
        if (text.isBlank() || text.length > 5000) return
        val items = load()
        val old = items.firstOrNull { it.text == text }
        items.removeAll { it.text == text }
        items.add(0, ClipItem(text, old?.pinned ?: false, System.currentTimeMillis()))
        var count = 0
        save(items.filter { if (it.pinned) true else { count++; count <= maxUnpinned } })
    }

    fun togglePin(text: String) {
        save(load().map { if (it.text == text) it.copy(pinned = !it.pinned) else it })
    }

    fun remove(text: String) {
        save(load().filter { it.text != text })
    }

    fun clearUnpinned() {
        save(load().filter { it.pinned })
    }

    fun clearAll() {
        save(emptyList())
    }

    /** Pinned first, then newest. */
    fun displayList(): List<ClipItem> {
        val l = load()
        return l.filter { it.pinned } + l.filter { !it.pinned }
    }

    fun latest(): ClipItem? = load().maxByOrNull { it.time }
}
